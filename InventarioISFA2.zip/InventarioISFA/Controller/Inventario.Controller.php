<?php
    Class Inventario
    {
        public function VerInventario()
        {
            echo "En ver inventario";
        }

        public function IngresoInventario()
        {
            $invet=new Invent();
            $smarty=new Smarty();

            $nombre=$_POST[];
            $desc=$_POST[];
            $cantidad=$_POST[];
            $precio=$_POST[];
            $fecha=$_POST[];

            $in=$invet->GuardarInventario($nombre,$desc,$cantidad,$precio,$fecha);
            $smarty->assign('nombre','Inventario');
            $smarty->display('Inventario.tpl')

        }
    }
?>