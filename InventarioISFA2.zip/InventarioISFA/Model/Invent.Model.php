<?php
    class  Invent
    {
        public function GuardarInventario($n,$d,$s,$c,$p,$f)
        {
            $con=new Conexion();

            $con=
        }
    }
?>